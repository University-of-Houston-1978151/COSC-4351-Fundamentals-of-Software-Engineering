function parseScores(scoresString) {
   // TODO: Compete the function
}

function buildDistributionArray(scoresArray) {
   // TODO: Compete the function
}

function setTableContent(userInput) {
   // TODO: Compete the function
}

// The argument can be changed for testing purposes
setTableContent("45 78 98 83 86 99 90 59");