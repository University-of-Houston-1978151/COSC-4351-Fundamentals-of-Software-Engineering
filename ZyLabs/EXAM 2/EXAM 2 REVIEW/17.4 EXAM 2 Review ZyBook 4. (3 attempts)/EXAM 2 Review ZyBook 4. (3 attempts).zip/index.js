function parseScores(scoresString) {
   
    // Your code here
}

