function calculate(){

   const enteredNum = prompt(); // Code will be tested with other values as well
   
   /* Your solution goes here */

   
}
